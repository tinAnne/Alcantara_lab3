import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, FlatList, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Image } from 'react-native';

export default function App() {
  const [inputText, setInputText] = useState('');
  const [items, setItems] = useState([]);

  const handleAddItem = () => {
    if (inputText.trim() === "") return;
    setItems([...items, inputText]);
    setInputText('');
  };

  return (
    <LinearGradient
      colors={['#3D365C','#898AC4', '#A2AADB', '#A2AADB']}
      style={styles.container}
    >
      <Text style={styles.title}>Favorite Designer Bags</Text>
      <Text style={styles.design}>✦•┈๑⋅⋯ ⋯⋅๑┈•✦</Text>

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Enter item"
          placeholderTextColor="#666"
          value={inputText}
          onChangeText={(text) => setInputText(text)}
        />

        <TouchableOpacity style={styles.button} onPress={handleAddItem}>
          <Text style={styles.buttonText}>ADD</Text>
        </TouchableOpacity>
      </View>

      <FlatList
        data={items}
        renderItem={({ item }) => (
      <View style={styles.itemBox}>
        <Image source={require('./assets/bag1.png')} style={styles.itemImage} />
        <Text style={styles.itemText}>{item}</Text>
      </View>
        )}
      />
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 22,
  },
  title: {
    fontFamily: "American Typewriter",
    fontSize: 27,
    fontWeight: '1000',
    textAlign: 'center',
    marginTop: 50,
    color: '#000',
  },
  design: {
    fontFamily: "American Typewriter",
    fontSize: 27,
    fontWeight: '1000',
    textAlign: 'center',
    marginBottom: 20,
    color: '#000',
  },
  inputContainer: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  input: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderWidth: 1.4,
    borderColor: '#C6C6C6',
    borderRadius: 50,
    paddingVertical: 10,
    paddingHorizontal: 14,
    fontSize: 16,
    color: '#000',
    elevation: 2,
  },
  button: {
    backgroundColor: '#000',
    paddingHorizontal: 20,
    justifyContent: 'center',
    borderRadius: 50,
    marginLeft: 10,
    elevation: 3,
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 17,
    fontFamily: "American Typewriter",
  },
  itemBox: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFFFFF',
    paddingVertical: 14,
    paddingHorizontal: 12,
    borderRadius: 50,
    borderWidth: 1,
    borderColor: '#92B5F4',
    marginBottom: 7,
    elevation: 2,
  },
  itemText: {
    fontFamily: "Jazz Let",
    fontSize: 22,
    color: '#000',
    fontWeight: '1000',
  },
  itemImage: {
  width: 24,
  height: 24,
  marginRight: 10,
  resizeMode: 'contain',
  },
});
